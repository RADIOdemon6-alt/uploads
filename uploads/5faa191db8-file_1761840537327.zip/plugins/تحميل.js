import yts from 'yt-search';
import fetch from 'node-fetch';

let handler = async (m, { conn, text }) => {
  if (!text) return conn.reply(m.chat, `
╭─︿︿︿︿︿︿︿︿╮
│✍️ أُكْتُبْ *اسـم الأُغْنِيَة* بَعْدَ الأمْر:
│مثال: .اغنيه lavender haze
╰─﹀﹀﹀﹀﹀﹀﹀﹀╯
`, m);

  try {
    await conn.sendMessage(m.chat, { react: { text: '🎶', key: m.key } });

    const search = await yts(text);
    if (!search.videos.length) return conn.reply(m.chat, '❌ لَمْ أَجِدْ أُغْنِيَةً بِهَذَا الإِسْمِ', m);

    const video = search.videos[0];
    const title = video.title;
    const artist = video.author.name;
    const url = video.url;
    const thumbUrl = video.thumbnail;
    const duration = video.timestamp;

    const res = await fetch(`https://bk9.fun/download/ytmp3?url=${encodeURIComponent(url)}&type=mp3`);
    const json = await res.json();
    if (!json.status || !json.BK9?.downloadUrl) {
      return conn.reply(m.chat, '⚠️ فَشَلَ فِي تَحْمِيلِ الأُغْنِيَة', m);
    }

    const audioUrl = json.BK9.downloadUrl;
    const thumbBuffer = await (await fetch(thumbUrl)).buffer();

    const caption = `
╮─ׅ─๋︩︪─┈─๋︩︪─═⊐‹✨›⊏═┈ ─๋︩︪─ ⊰ـ
┤┌─๋︩︪─✦المعلومات☇─˚𖥻
│┊ ۬.͜ـ🎵˖ ⟨الاسم: ${title}⟩
│┊ ۬.͜ـ🎙️˖ ⟨الفنان: ${artist}⟩
│┊ ۬.͜ـ⏱️˖ ⟨المدة: ${duration}⟩
│┊ ۬.͜ـ🔗˖ ⟨الرابط: ${url}⟩
┤└─ׅ─ׅ┈ ─๋︩︪──ׅ─ׅ┈ ─๋︩︪☇ـ
╯─ׅ ─๋︩︪─┈ ─๋︩︪─═⊐‹✅›⊏═┈ ─๋︩︪─ ⊰ـ
`;

    await conn.sendMessage(m.chat, {
      audio: { url: audioUrl },
      mimetype: 'audio/mpeg',
      fileName: `${title}.mp3`,
      ptt: false,
      caption,
      contextInfo: {
        externalAdReply: {
          title: title,
          body: `الفنان: ${artist}`,
          thumbnail: thumbBuffer,
          mediaType: 1,
          renderLargerThumbnail: true,
          mediaUrl: url,
          sourceUrl: url
        }
      }
    }, { quoted: m });

    await conn.sendMessage(m.chat, { react: { text: '✅', key: m.key } });

  } catch (e) {
    console.error(e);
    await conn.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
    m.reply('⚠️ حَدَثَ خَطَأ، حَاوِلْ مَرَّةً أُخْرَى.');
  }
};

handler.command = ['تحمل'];
handler.tags = ['music'];
handler.help = ['ابل [اسم الأغنية]'];
handler.limit = false;

export default handler;