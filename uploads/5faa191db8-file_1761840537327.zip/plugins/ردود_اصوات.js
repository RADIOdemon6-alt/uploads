import fetch from 'node-fetch'
import fs from 'fs'
import path from 'path'
import { spawn } from 'child_process'

let handler = async (m, { conn }) => {
  try {
    const content = (m.text || m.message?.reactionMessage?.text || '').toLowerCase()
    if (!content) return

    const thumbnailUrl = 'https://raw.githubusercontent.com/RADIOdemon6-alt/uploads/main/uploads/3e0989797e-file_1761645709658.jpg'

    // 🎧 الردود
    const replies = {
      insult: {
        keywords: /(بوت زفت|بوت زق|بوت خرا|بوت وسخ)/i,
        first: 'https://raw.githubusercontent.com/RADIOdemon6-alt/uploads/main/uploads/c349a12ff1-file_1761814537601.opus',
        repeat: 'https://raw.githubusercontent.com/RADIOdemon6-alt/uploads/main/uploads/2df97d9fe9-file_1761814708844.mp3'
      },
      bot: {
        keywords: /بوت/i,
        url: 'https://raw.githubusercontent.com/RADIOdemon6-alt/uploads/main/uploads/65d07ff820-file_1761814486497.opus'
      },
      morning: {
        keywords: /صباح الخير/i,
        url: 'https://raw.githubusercontent.com/RADIOdemon6-alt/uploads/main/uploads/dc9d2a57d4-file_1761814778247.opus'
      },
      insulted: {
        keywords: /البوت شتمني/i,
        url: 'https://raw.githubusercontent.com/RADIOdemon6-alt/uploads/main/uploads/b287bbf7c7-file_1761814977459.mp3'
      },
      dev: {
        keywords: /(متغلنيش (افشخ|انيكك)|اسكت بدل ما افوم افشخك)/i,
        url: 'https://raw.githubusercontent.com/RADIOdemon6-alt/uploads/main/uploads/1fbc1f2df2-file_1761815056212.mp3',
        raw: true
      },
      better: {
        keywords: /(احسن منك|انا اقوى منك|كسمك)/i,
        first: 'https://raw.githubusercontent.com/RADIOdemon6-alt/uploads/main/uploads/52db2f72d6-file_1761815128603.mp3',
        repeat: 'https://raw.githubusercontent.com/RADIOdemon6-alt/uploads/main/uploads/263ff60d28-file_1761819081174.mp3',
        raw: true
      },
      identity: {
        keywords: /(مش عارف انا ابقي مين|مش عارف انا مين|يبن المتناكه|دنا هنيكك|كسمينك)/i,
        url: 'https://raw.githubusercontent.com/RADIOdemon6-alt/uploads/main/uploads/263ff60d28-file_1761819081174.mp3',
        raw: true
      }
    }

    // 🔍 تحديد الرد المناسب
    let selected = null
    for (const key in replies) {
      if (replies[key].keywords.test(content)) {
        selected = replies[key]
        break
      }
    }
    if (!selected) return

    await conn.sendMessage(m.chat, { react: { text: '⏳', key: m.key } })

    let audioUrl
    const user = m.sender

    // 🧠 التعامل مع التكرار
    if (selected === replies.insult) {
      if (!global._insultedUsers) global._insultedUsers = {}
      if (global._insultedUsers[user]) audioUrl = selected.repeat
      else {
        audioUrl = selected.first
        global._insultedUsers[user] = true
        setTimeout(() => delete global._insultedUsers[user], 5 * 60 * 1000)
      }
    } else if (selected === replies.better) {
      if (!global._ksmkUsers) global._ksmkUsers = {}
      if (global._ksmkUsers[user]) audioUrl = selected.repeat
      else {
        audioUrl = selected.first
        global._ksmkUsers[user] = true
        setTimeout(() => delete global._ksmkUsers[user], 5 * 60 * 1000)
      }
    } else {
      audioUrl = selected.url
    }

    // 📥 تحميل الصوت
    const tempDir = './tmp'
    if (!fs.existsSync(tempDir)) fs.mkdirSync(tempDir)
    const ext = path.extname(audioUrl).split('?')[0] || '.mp3'
    const inputPath = path.join(tempDir, `input_${Date.now()}${ext}`)
    const outputPath = path.join(tempDir, `output_${Date.now()}.opus`)

    const res = await fetch(audioUrl)
    if (!res.ok) throw new Error(`فشل تحميل الصوت: ${res.statusText}`)
    fs.writeFileSync(inputPath, Buffer.from(await res.arrayBuffer()))

    // 🎧 إرسال مباشر (raw)
    if (selected.raw) {
      await conn.sendMessage(m.chat, {
        audio: fs.readFileSync(inputPath),
        mimetype: 'audio/mpeg',
        ptt: false
      }, { quoted: m })

      fs.unlinkSync(inputPath)
      await conn.sendMessage(m.chat, { react: { text: '🔊', key: m.key } })
      return
    }

    // 🎚️ تحويل إلى opus
    await new Promise((resolve, reject) => {
      const ff = spawn('ffmpeg', ['-y', '-i', inputPath, '-c:a', 'libopus', '-b:a', '128k', outputPath])
      ff.on('close', code => code === 0 ? resolve() : reject(new Error('فشل تحويل الصوت')))
    })

    const finalBuffer = fs.readFileSync(outputPath)
    const resThumb = await fetch(thumbnailUrl)
    const thumbnail = Buffer.from(await resThumb.arrayBuffer())

    // 🎙️ إرسال الصوت العادي
    await conn.sendMessage(m.chat, {
      audio: finalBuffer,
      mimetype: 'audio/ogg; codecs=opus',
      ptt: true,
      fileName: 'RADIO-DEMON.opus',
      contextInfo: {
        externalAdReply: {
          title: "🚫┇≡ ◡̈⃝⚰️•⪼ 𝑅𝐴𝐷𝐼𝛩 𝐷𝐸𝑀𝛩𝑁",
          body: "𖥔ᰔᩚ⋆｡˚ ꒰🍒 ʀᴜʙʏ-ʜᴏꜱʜɪɴᴏ",
          thumbnail,
          mediaType: 1,
          renderLargerThumbnail: true,
          mediaUrl: "https://wa.me/201500564191"
        }
      }
    }, { quoted: m })

    await conn.sendMessage(m.chat, { react: { text: '🔊', key: m.key } })
    fs.unlinkSync(inputPath)
    fs.unlinkSync(outputPath)
  } catch (e) {
    console.error('❌ خطأ:', e)
  }
}

// ✅ التفعيل التلقائي فقط لو الكلمة موجودة
handler.before = async (m, { conn }) => {
  const content = (m.text || m.message?.reactionMessage?.text || '').toLowerCase()
  if (!content) return
  const trigger = /(بوت|زفت|زق|خرا|وسخ|متغلنيش|افشخ|انيكك|اسكت بدل ما افوم افشخك|صباح الخير|البوت شتمني|احسن منك|انا اقوى منك|كسمك|مش عارف انا ابقي مين|مش عارف انا مين|يبن المتناكه|دنا هنيكك|كسمينك)/i
  if (trigger.test(content)) await handler(m, { conn })
}

export default handler