import axios from "axios";

let handler = async (m, { conn, text }) => {
    if (!text) throw "⚠️ الرجاء إدخال كلمة للبحث عن فيديو في Pinterest.\n\nمثال:\n*.بين* nayeon";

    try {
        await m.reply("⌛ جاري البحث في Pinterest...\nلا تنسى المتابعة: instagram.com/noureddine_ouafy");

        const pins = await searchPinterest(text);

        if (!pins || pins.length === 0) throw "❌ لم يتم العثور على أي فيديوهات.";

        // نحاول نرسل أول فيديو فقط
        let sent = false;

        for (const pin of pins) {
            if (pin.link && pin.link.includes('pinterest.com/pin/')) {
                try {
                    const { medias, title } = await pindl(pin.link);
                    let mp4 = medias.filter(v => v.extension === "mp4");

                    if (mp4.length > 0) {
                        const size = formatSize(mp4[0].size);
                        await conn.sendMessage(
                            m.chat,
                            { 
                                video: { url: mp4[0].url }, 
                                caption: `\`${title}\`\nالجودة: ${mp4[0].quality}\nالحجم: ${size}` 
                            },
                            { quoted: m }
                        );
                        sent = true;
                        break;
                    }
                } catch (e) {
                    // تجاهل الخطأ واستمر
                    continue;
                }
            }
        }

        if (!sent) throw "❌ لم يتم العثور على فيديوهات صالحة في النتائج.";

    } catch (e) {
        throw `حدث خطأ: ${e}`;
    }
};

handler.help = ["بين <كلمة>"];
handler.command = /^(بين)$/i;
handler.tags = ["downloader"];

export default handler;

// دالة للبحث في Pinterest
async function searchPinterest(query) {
    try {
        const res = await axios.get(`https://api.purpl3.dev/api/pinterest?q=${encodeURIComponent(query)}`);
        return res.data?.data || [];
    } catch (e) {
        console.error("Pinterest Search Error:", e.message);
        throw "حدث خطأ أثناء البحث في Pinterest.";
    }
}

// دالة التحميل من رابط مباشر
async function pindl(url) {
    try {
        const apiEndpoint = 'https://pinterestdownloader.io/frontendService/DownloaderService';
        const params = { url };
        let { data } = await axios.get(apiEndpoint, { params });
        if (!data || !data.medias) throw "Invalid API response.";
        return data;
    } catch (e) {
        throw "فشل في التحميل من