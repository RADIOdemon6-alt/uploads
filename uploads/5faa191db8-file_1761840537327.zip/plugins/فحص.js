import fs from 'fs';
import path from 'path';
import chalk from 'chalk';
import fetch from 'node-fetch';

// تغليف fetch لفحص الاستجابة
const safeFetch = async (url, options = {}) => {
  try {
    const res = await fetch(url, options);
    const contentType = res.headers.get('content-type') || '';
    let data;

    if (contentType.includes('application/json')) {
      data = await res.json();
    } else {
      data = await res.text();
    }

    if (!res.ok || (typeof data === 'object' && (data.error || data.status === false))) {
      throw new Error(`استجابة API تالفة أو تحتوي على خطأ: ${JSON.stringify(data)}`);
    }

    console.log(chalk.green('[API OK]'), url);
    return data;
  } catch (err) {
    console.error(chalk.red('[API ERROR]'), url, err.message);
    throw err;
  }
};

const handler = async (m, { conn }) => {
  const pluginDir = './plugins';
  const files = fs.readdirSync(pluginDir).filter(file => file.endsWith('.js'));

  if (files.length === 0) return m.reply('🧞 لا يوجد أي بلوجنات للتنفيذ.');

  m.reply(`🧞 جاري تحميل وتشغيل ${files.length} بلوجن...\n`);

  for (const file of files) {
    const fullPath = path.join(pluginDir, file);
    try {
      const plugin = await import(path.resolve(fullPath));

      if (plugin?.default?.handler) {
        // تمرير safeFetch إلى البلوجن إذا كان يستخدم API
        await plugin.default.handler(m, { conn, text: '', usedPrefix: '', command: '', fetch: safeFetch });
        m.reply(`✅ تم تنفيذ البلوجن: ${file}`);
      } else {
        console.log(chalk.yellow(`⚠️ لا يوجد handler في ${file}`));
      }
    } catch (e) {
      m.reply(`❌ خطأ في تشغيل البلوجن ${file}:\n${e.message}`);
    }
  }

  m.reply('🧞 انتهى تنفيذ جميع البلوجنز.');
};

handler.help = ['تشغيل_الكل'];
handler.command = ['فحص'];
handler.tags = ['tools'];

export default handler;