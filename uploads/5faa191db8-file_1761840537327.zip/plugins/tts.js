import axios from "axios";
import fs from "fs";
import path from "path";

let handler = async (m, { conn, text, usedPrefix, command }) => {
  if (!text) return m.reply(`❌ الاستخدام:\n${usedPrefix + command} النص المطلوب تحويله لصوت\n\nمثال:\n${usedPrefix + command} مرحباً كيف حالك؟`);

  try {
    // 1. الحصول على قائمة الأصوات
    const voicesRes = await axios.get("https://developer-services.vercel.app/api/v1/Ai/createVoice/elevenlabsvoices");
    const voices = voicesRes.data?.voices || [];

    if (!voices.length) return m.reply("❌ لم يتم العثور على أي أصوات متاحة.");

    // نختار أول صوت male (لو موجود)
    let speaker = voices.find(v => v.gender === "male")?.name || voices[0].name;

    // 2. توليد الصوت
    const url = "https://developer-services.vercel.app/api/v1/Ai/createVoice/elevenlabsspeech";
    const outFile = path.join("./tmp", `tts-${Date.now()}.mp3`);

    const response = await axios.post(url, {
      text,
      gender: "male",
      speaker,
      speed: 0.9,
      stability: 0.85,
      similarity: 0.88
    }, {
      responseType: "arraybuffer"
    });

    // 3. حفظ وإرسال الصوت
    fs.writeFileSync(outFile, response.data);

    await conn.sendMessage(m.chat, {
      audio: fs.readFileSync(outFile),
      mimetype: "audio/mpeg",
      ptt: true
    }, { quoted: m });

    fs.unlinkSync(outFile);

  } catch (err) {
    console.error(err.response?.data || err);
    m.reply("❌ حدث خطأ أثناء توليد الصوت (تحقق من API أو البرامترات).");
  }
};

handler.help = ["tts"];
handler.tags = ["ai"];
handler.command = ["tts", "صوت", "تحويل"];

export default handler;