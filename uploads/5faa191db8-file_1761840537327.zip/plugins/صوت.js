import axios from "axios";

let handler = async (m, { args }) => {
  if (!args[0]) return m.reply("❌ اكتب النص اللي عايز تحوله لصوت.");

  let text = args.join(" ");

  try {
    // ✅ غوكو VoiceID
    let buffer = await fakeyouTTS(text, "TM:7x3x5m5f5r4d");

    if (!buffer) return m.reply("❌ فشل تحويل النص لصوت.");

    await conn.sendMessage(
      m.chat,
      { audio: buffer, mimetype: "audio/mpeg", ptt: true },
      { quoted: m }
    );
  } catch (err) {
    console.error("TTS Error:", err.message);
    m.reply("❌ حصل خطأ أثناء تحويل النص لصوت.");
  }
};

handler.help = ["انمي_صوت"];
handler.tags = ["fun"];
handler.command = ["صوت"];

export default handler;

// 🟢 FakeYou TTS Function
async function fakeyouTTS(text, voiceId) {
  try {
    console.log("⏳ بدء إنشاء الصوت...");

    // 1. إنشاء الـ job
    let { data } = await axios.post(
      "https://api.fakeyou.com/tts/inference",
      {
        tts_model_token: voiceId,
        inference_text: text,
      },
      {
        headers: {
          "Content-Type": "application/json",
          "User-Agent":
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/116.0.0.0 Safari/537.36",
          Referer: "https://fakeyou.com/",
        },
      }
    );

    if (!data?.inference_job_token) {
      console.error("🚨 مفيش job token:", data);
      return null;
    }

    let jobToken = data.inference_job_token;
    console.log("✅ Job Token:", jobToken);

    // 2. متابعة حالة الـ job
    let audioUrl;
    for (let i = 0; i < 15; i++) {
      await new Promise((r) => setTimeout(r, 3000));

      let job = await axios.get(
        `https://api.fakeyou.com/tts/job/${jobToken}`,
        {
          headers: {
            "User-Agent":
              "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/116.0.0.0 Safari/537.36",
          },
        }
      );

      let status = job.data?.state?.status;
      console.log("📡 حالة الـ Job:", status);

      if (status === "complete_success") {
        audioUrl =
          "https://storage.googleapis.com/vocodes-public" +
          job.data.state.maybe_public_bucket_wav_audio_path;
        break;
      }

      if (status === "complete_failure") {
        console.error("🚨 فشل:", job.data);
        return null;
      }
    }

    if (!audioUrl) {
      console.error("🚨 الصوت ماجهزش.");
      return null;
    }

    console.log("🔗 Audio URL:", audioUrl);

    // 3. تحميل الصوت
    let res = await axios.get(audioUrl, { responseType: "arraybuffer" });
    return Buffer.from(res.data);
  } catch (err) {
    console.error("FakeYou Error:", err.message);
    return null;
  }
}