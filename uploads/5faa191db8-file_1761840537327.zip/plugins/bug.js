import { exec } from "child_process";
import fs from "fs";
import path from "path";

const ELEVEN_API_KEY = "sk_e4146df3bd07d3cd9b28647f14011214912d211bec6d8fef"; // 🔑 حط التوكن بتاعك

let handler = async (m, { conn, command, args, text }) => {
  // 🎤 أمر جلب قائمة الأصوات
  if (command === "listvoices") {
    const cmd = `curl -s -X GET "https://api.elevenlabs.io/v1/voices" \
      -H "xi-api-key: ${ELEVEN_API_KEY}"`;

    exec(cmd, (err, stdout) => {
      if (err) {
        console.error(err);
        return m.reply("❌ حصل خطأ أثناء جلب الأصوات.");
      }

      try {
        const data = JSON.parse(stdout);
        if (!data.voices) return m.reply("❌ لم يتم العثور على أصوات.");

        let msg = "🎤 *الأصوات المتاحة:*\n\n";
        data.voices.forEach((v, i) => {
          msg += `${i + 1}. ${v.name} → ID: ${v.voice_id}\n`;
        });

        m.reply(msg);
      } catch (e) {
        console.error(e);
        m.reply("❌ فشل في قراءة الأصوات.");
      }
    });
    return;
  }

  // 🎙️ أمر تحويل النص لصوت
  if (!text) return m.reply("❌ اكتب النص المطلوب تحويله لصوت\n\n📌 مثال:\n.tts <voice_id>|النص");

  if (!fs.existsSync("./tmp")) fs.mkdirSync("./tmp");

  // لو المستخدم كتب voice_id|النص
  let voiceId = "21m00Tcm4TlvDq8ikWAM"; // الافتراضي (Rachel)
  let inputText = text;

  if (text.includes("|")) {
    const [id, ...rest] = text.split("|");
    voiceId = id.trim();
    inputText = rest.join("|").trim();
  }

  const filePath = path.join("./tmp", `tts-${Date.now()}.mp3`);
  const safeText = inputText.replace(/"/g, '\\"');

  const cmd = `curl -s -X POST "https://api.elevenlabs.io/v1/text-to-speech/${voiceId}" \
    -H "xi-api-key: ${ELEVEN_API_KEY}" \
    -H "Content-Type: application/json" \
    -d '{ "text": "${safeText}", "voice_settings": { "stability": 0.7, "similarity_boost": 0.9 } }' \
    --output "${filePath}"`;

  exec(cmd, async (err) => {
    if (err) {
      console.error(err);
      return m.reply("❌ حصل خطأ أثناء توليد الصوت.");
    }

    try {
      await conn.sendMessage(
        m.chat,
        {
          audio: fs.readFileSync(filePath),
          mimetype: "audio/mpeg",
          ptt: true
        },
        { quoted: m }
      );
    } catch (e) {
      console.error(e);
      m.reply("❌ فشل إرسال الصوت.");
    } finally {
      if (fs.existsSync(filePath)) fs.unlinkSync(filePath);
    }
  });
};

handler.help = ["tts <نص>", "tts <voice_id>|<نص>", "listvoices"];
handler.tags = ["ai"];
handler.command = ["tts", "صوت", "تحويل", "listvoices"];

export default handler;