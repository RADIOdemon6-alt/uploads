import axios from 'axios'
import FormData from 'form-data'

let handler = async (m, { conn }) => {
    if (!m.quoted || !m.quoted.mimetype || !m.quoted.mimetype.includes('audio')) {
        return m.reply('⌯ رد على صوت عشان اعزلو')
    }

    try {
        const audio = await m.quoted.download()
        const form = new FormData()
        form.append('audio', audio, 'audio.mp3')

        const uploadResponse = await axios.post(
            'https://the-end-api.vercel.app/home/sections/Tools/api/voiceremover/upload', 
            form, 
            { headers: form.getHeaders() }
        )

        if (!uploadResponse.data.status) {
            throw new Error('⌯ فشل في الرفع')
        }

        const { file_name, key } = uploadResponse.data

        while (true) {
            await new Promise(resolve => setTimeout(resolve, 3000))
            const processResponse = await axios.get(
                'https://the-end-api.vercel.app/home/sections/Tools/api/voiceremover/process', 
                { params: { file_name, key } }
            )

            if (processResponse.data.status && processResponse.data.instrumental_path) {
                await conn.sendMessage(m.chat, {
                    audio: { url: processResponse.data.instrumental_path },
                    mimetype: 'audio/mpeg',
                    fileName: 'instrumental.mp3'
                }, { quoted: m })

                if (processResponse.data.vocal_path) {
                    await conn.sendMessage(m.chat, {
                        audio: { url: processResponse.data.vocal_path },
                        mimetype: 'audio/mpeg',
                        fileName: 'vocals.mp3'
                    }, { quoted: m })
                }
                break
            }
        }
    } catch (e) {
        m.reply(`⌯ حدث خطأ: ${e.message}`)
    }
}

handler.command = ['عزل']
handler.tags = ['tools']
handler.help = ['عزل']
export default handler