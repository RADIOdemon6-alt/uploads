let handler = m => m;

let canalId = ["120363160031023229@newsletter", "120363355261011910@newsletter"];
let canalNombre = ["INFINITY-WA 💫", "LoliBot ✨"];

handler.all = async function (m, { conn }) {
  if (m.key.fromMe) return;

  let chat = global.db.data.chats[m.chat];
  if (chat?.isBanned) return;

  let isFromChannel = canalId.includes(m.chat);
  if (isFromChannel) {
    console.log("تم استقبال رسالة من قناة:", m.chat);
  }

  const sendAdReply = async (text) => {
    await conn.sendMessage(m.chat, {
      text,
      contextInfo: {
        externalAdReply: {
          title: "𝙱𝚈 𝚁𝙰𝙳𝙸𝙾 𝙳𝙴𝙼𝙾𝙽",
          body: isFromChannel ? `مرسلة من ${canalNombre[canalId.indexOf(m.chat)]}` : "𝐀𝐁𝐘𝐒𝐒|𝐁𝐎𝐓",
          thumbnailUrl: "https://stitch-api.vercel.app/api/v3/upload/view/image5w7he.jpg",
          sourceUrl: "https://whatsapp.com/channel/0029VaENL4h1lD3MZsVEty",
          mediaType: 1,
          showAdAttribution: true,
          renderLargerThumbnail: false
        }
      }
    }, { quoted: m });
  };

  // مثال بسيط فقط للتجربة على قناة
  if (/^تجربه$/i.test(m.text)) await sendAdReply("*رد تجريبي على القناة أو الشات*");

  return !0;
};

export default handler;