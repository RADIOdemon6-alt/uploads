import fs from "fs";
import path from "path";
import fetch from "node-fetch";
import { execSync } from "child_process";

// 🌟 متغير واحد لتغيير API بسهولة
let AI_API_BASE = "https://alakreb.vercel.app/api/ai/gpt?q=";

const ELEVEN_API_KEY = "sk_e4146df3bd07d3cd9b28647f14011214912d211bec6d8fef";
const voiceId = "XB0fDUnXU5powFXDhCwa"; // صوت شارلوت

const conversationHistory = {};

let handler = async (m, { text, conn }) => {
  if (!text) return m.reply("❌ اكتب نص بعد الأمر.\nمثال: `.ابيس كيف حالك؟`");

  const userText = text.trim();
  const userId = m.sender;

  try {
    // 1️⃣ جلب الرد من API مع حفظ السياق
    let aiReply = await getAIReply(userText, userId);

    if (!aiReply || aiReply === userText) aiReply = "Sorry, I did not understand.";

    // 2️⃣ تنظيف النص قبل TTS
    const cleanText = aiReply.replace(/\\/g, "\\\\").replace(/"/g, '\\"').replace(/\n/g, " ");

    // 3️⃣ تحويل النص إلى صوت
    const audioBuffer = await generateTTSBuffer(cleanText);

    // 4️⃣ تحميل صورة للإعلان
    const thumbnailUrl = "https://files.catbox.moe/jum4bn.jpg";
    const res = await fetch(thumbnailUrl);
    if (!res.ok) throw new Error(`فشل تحميل الصورة: ${res.statusText}`);
    const thumbnail = Buffer.from(await res.arrayBuffer());

    // 5️⃣ إرسال الصوت مع Ad Reply دائماً
    await conn.sendMessage(m.chat, {
      audio: audioBuffer,
      mimetype: "audio/mpeg",
      ptt: true,
      fileName: "AI-REPLY.mp3",
      contextInfo: {
        externalAdReply: {
          title: "🚫┇≡ ◡̈⃝⚰️•⪼ AI BOT",
          body: "🎤┇≡ ◡̈⃝🎼•⪼ ABYSS|BOT",
          thumbnail,
          mediaType: 1,
          renderLargerThumbnail: true,
          mediaUrl: "https://wa.me/201500564191",
          sourceUrl: "https://wa.me/201500564191",
        },
      },
    }, { quoted: m });

  } catch (err) {
    console.error(err);
    m.reply("❌ حدث خطأ أثناء إرسال الرد الصوتي.");
  }
};

// دالة تحويل النص إلى صوت
async function generateTTSBuffer(text) {
  if (!fs.existsSync('./tmp')) fs.mkdirSync('./tmp');
  const filePath = path.join("./tmp", `tts-${Date.now()}.mp3`);

  const cmd = `curl -s -X POST "https://api.elevenlabs.io/v1/text-to-speech/${voiceId}" \
-H "xi-api-key: ${ELEVEN_API_KEY}" \
-H "Content-Type: application/json" \
-d '{ "text": "${text}", "voice_settings": { "stability": 0.7, "similarity_boost": 0.9 } }' \
--output ${filePath}`;

  execSync(cmd);

  const buffer = fs.readFileSync(filePath);
  fs.unlinkSync(filePath);
  return buffer;
}

// دالة جلب الرد من API مع حفظ السياق
async function getAIReply(userText, userId) {
  try {
    if (!conversationHistory[userId]) conversationHistory[userId] = [];

    conversationHistory[userId].push({ role: "user", content: userText });
    if (conversationHistory[userId].length > 10) conversationHistory[userId].shift();

    const response = await fetch(AI_API_BASE + encodeURIComponent(userText));
    const data = await response.json();
    const reply = data.message?.trim() || "";

    conversationHistory[userId].push({ role: "assistant", content: reply });
    return reply;

  } catch (err) {
    console.error(err);
    return "Sorry, I did not understand.";
  }
}

handler.help = ["ابيس <نص>"];
handler.tags = ["ai"];
handler.command = ["ابيس"];
export default handler;