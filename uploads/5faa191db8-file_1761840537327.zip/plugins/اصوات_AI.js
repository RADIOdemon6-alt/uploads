import { exec } from "child_process";
import fs from "fs";
import path from "path";

const ELEVEN_API_KEY = "sk_e4146df3bd07d3cd9b28647f14011214912d211bec6d8fef"; // 🔑 ضع مفتاحك هنا

// 🟢 خريطة الأصوات (أنثوية + ذكرية)
const voicesMap = {
  // أنثوية
  "أليس": "Xb7hH8MSUJpSbSDYk0k2",      // Alice
  "شارلوت": "XB0fDUnXU5powFXDhCwa",   // Charlotte
  "دو مي": "AZnzlk1XvdvUeBnXmlld",    // Domi
  "دوروثي": "ThT5KcBeYPX3keUQqHPh",  // Dorothy
  "إميلي": "LcfcDJNUP1GQjkzn1xUU",   // Emily
  "فريا": "jsCqWAovK2LkecY7zXl4",    // Freya
  "جيجي": "jBpfuIE2acCO8z3wKNLl",    // Gigi
  "غليندا": "z9fAnlkpzviPz146aGWa",  // Glinda

  // ذكرية
  "آدم": "pNInz6obpgDQGcFmaJgB",      // Adam
  "أنتوني": "ErXwobaYiN019PkySvjV",  // Antoni
  "أرنولد": "VR6AewLTigWG4xSOukaG",  // Arnold
  "بيل": "pqHfZKP75CvOlQylNhV4",     // Bill
  "برايان": "nPczCjzI2devNBz1zQrb",   // Brian
  "كالوم": "N2lVS1w4EtoT3dr4eOWO",   // Callum
  "تشارلي": "IKne3meq5aSn9XLyUdCD",  // Charlie
  "كريس": "iP95p4xoKVk53GoZ742B",    // Chris
  "كلايد": "2EiwWnXFnvU5JabPnv8n",   // Clyde
  "دانيال": "onwK4e9ZLuTAKqWW03F9",  // Daniel
  "ديف": "CYw3kZ02Hs0563khs1Fj",     // Dave
  "إيثان": "g5CIjZEefAph4nQFvHAz",   // Ethan
  "فن": "D38z5RcWu1voky8WS1ja",      // Fin
  "جورج": "JBFqnCBsd6RMkjVDRZzb",    // George
  "جيوفاني": "zcAOhNBS3c14rBihAFp1"  // Giovanni
};

let handler = async (m, { text, command, conn }) => {
  if (!text) return m.reply("❌ اكتب النص بعد اسم الصوت.\nمثال: `.أليس مرحبا بك`");

  let voiceId = voicesMap[command]; // نجيب ID الصوت من اسم الأمر

  if (!voiceId) {
    return m.reply(`❌ الصوت "${command}" غير موجود في القائمة.`);
  }

  const filePath = path.join("./tmp", `tts-${Date.now()}.mp3`);

  const cmd = `curl -s -X POST "https://api.elevenlabs.io/v1/text-to-speech/${voiceId}" \
    -H "xi-api-key: ${ELEVEN_API_KEY}" \
    -H "Content-Type: application/json" \
    -d '{ "text": "${text}", "voice_settings": { "stability": 0.7, "similarity_boost": 0.9 } }' \
    --output ${filePath}`;

  exec(cmd, async (err) => {
    if (err) {
      console.error(err);
      return m.reply("❌ حصل خطأ أثناء توليد الصوت.");
    }

    await conn.sendMessage(m.chat, {
      audio: fs.readFileSync(filePath),
      mimetype: "audio/mpeg",
      ptt: true
    }, { quoted: m });

    fs.unlinkSync(filePath);
  });
};

// 🟢 نخلي كل الأوامر = أسماء الأصوات (بالعربي)
handler.help = Object.keys(voicesMap).map(v => `${v} <نص>`);
handler.tags = ["ai"];
handler.command = Object.keys(voicesMap);

export default handler;