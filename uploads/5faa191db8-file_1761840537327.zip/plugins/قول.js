import axios from "axios";

let radioVoices = {
  "takumi": "Takumi",
  "haruka": "Haruka",
  "mizuki": "Mizuki",
  "joey": "Joey",
  "russell": "Russell",
  "ivy": "Ivy",
  "emma": "Emma",
  "salli": "Salli",
  "brian": "Brian",
  "amy": "Amy",
};

let RadioVoiceTTS = async (m, { args, conn }) => {
  if (args.length < 2)
    return m.reply("❌ الاستخدام: .tts <الصوت> <النص>\n\n🎙️ الأصوات المتاحة:\n" + Object.keys(radioVoices).join(", "));

  const voiceKey = args[0].toLowerCase();
  const text = args.slice(1).join(" ");

  if (!radioVoices[voiceKey])
    return m.reply("❌ الصوت غير متوفر.\n\n🎧 الأصوات المدعومة:\n" + Object.keys(radioVoices).join(", "));

  try {
    const audioBuffer = await getRadioVoiceTTS(text, radioVoices[voiceKey]);
    if (!audioBuffer) return m.reply("❌ فشل في تحويل النص إلى صوت.");

    await conn.sendMessage(
      m.chat,
      { audio: audioBuffer, mimetype: "audio/mpeg", ptt: true },
      { quoted: m }
    );
} catch (error) {
    console.error("TTS Error:", error);
    m.reply("❌ حدث خطأ أثناء تحويل النص لصوت.");
  }
};

RadioVoiceTTS.help = ["tts"];
RadioVoiceTTS.tags = ["tools"];
RadioVoiceTTS.command = ["قول", "صوت"];

export default RadioVoiceTTS;

async function getRadioVoiceTTS(text, voice = "Takumi") {
  try {
    let { data } = await axios.post(
      "https://ttsmp3.com/makemp3_new.php",
      new URLSearchParams({
        msg: text,
        lang: voice,
        source: "ttsmp3",
      }),
      {
        headers: {
          "Content-Type": "application/x-www-form-urlencoded",
          "User-Agent":
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/116.0.0.0 Safari/537.36",
          Referer: "https://ttsmp3.com/",
        },
      }
    );

    if (!data || !data.URL) throw new Error("❌ لم يتم إرجاع رابط الصوت");

    let res = await axios.get(data.URL, { responseType: "arraybuffer" });
    return Buffer.from(res.data);
  } catch (err) {
    console.error("TTS Fetch Error:", err.message);
    return null;
  }
}