import axios from "axios";

let arabicVoices = {
  "zeina": "Zeina", // صوت أنثوي عربي
  "omar": "Omar",   // صوت ذكوري عربي
};

let handler = async (m, { args, conn }) => {
  if (args.length < 2)
    return m.reply("❌ الاستخدام: .tts <zeina|omar> <النص>");

  const voiceKey = args[0].toLowerCase();
  const text = args.slice(1).join(" ");

  if (!arabicVoices[voiceKey])
    return m.reply("❌ الصوت غير متوفر. الأصوات المتاحة: zeina, omar");

  try {
    const audioBuffer = await getTTS(text, arabicVoices[voiceKey]);
    if (!audioBuffer) return m.reply("❌ فشل تحويل النص لصوت.");

    await conn.sendMessage(
      m.chat,
      { audio: audioBuffer, mimetype: "audio/mpeg", ptt: true },
      { quoted: m }
    );
  } catch (err) {
    console.error("TTS Error:", err);
    m.reply("❌ حدث خطأ أثناء تحويل النص لصوت.");
  }
};

handler.help = ["tts"];
handler.tags = ["tools"];
handler.command = ["tts", "تست2"];

export default handler;

// 🟢 Scraping TTS بالعربي باستخدام Axios + Headers
async function getTTS(text, voice = "Zeina") {
  try {
    // طلب توليد الصوت
    let { data } = await axios.post(
      "https://ttsmp3.com/makemp3_new.php",
      new URLSearchParams({
        msg: text,
        lang: voice, // Zeina أو Omar
        source: "ttsmp3",
      }),
      {
        headers: {
          "Content-Type": "application/x-www-form-urlencoded",
          "User-Agent":
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/116.0.0.0 Safari/537.36",
          Referer: "https://ttsmp3.com/",
        },
      }
    );

    if (!data || !data.URL) throw new Error("No audio URL returned");

    // تحميل الصوت كـ Buffer
    let res = await axios.get(data.URL, { responseType: "arraybuffer" });
    return Buffer.from(res.data);
  } catch (err) {
    console.error("Direct TTS Error:", err.message);
    return null;
  }
}